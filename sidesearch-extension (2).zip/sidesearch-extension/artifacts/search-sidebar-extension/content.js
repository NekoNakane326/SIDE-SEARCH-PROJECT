/**
 * content.js — runs in the ISOLATED world at document_start.
 * injected.js is now loaded directly via "world": "MAIN" in manifest.json,
 * so this file only needs to relay panel-state messages into the page.
 */

chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "PANEL_STATE") {
    window.postMessage({ __sidesearch_panel: msg.open }, "*");
  }
});
