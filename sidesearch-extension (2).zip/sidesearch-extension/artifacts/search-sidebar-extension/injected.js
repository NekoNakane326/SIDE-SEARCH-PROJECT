/**
 * injected.js — runs in the PAGE's JS world via "world": "MAIN" content script.
 *
 * Because this is declared as a content_script with world: "MAIN" and
 * run_at: "document_start", it executes synchronously before ANY page script
 * (including Canvas). That means our property overrides are in place before
 * Canvas can cache references to the native APIs.
 *
 * Suppression is ONLY active while panelOpen = true.
 */
(function () {
  "use strict";

  let panelOpen = false;
  let lastActiveElement = null;

  // ── 1. Receive panel-state from content.js relay ──────────────────────────
  window.addEventListener("message", (e) => {
    if (e.source === window && e.data && e.data.__sidesearch_panel != null) {
      panelOpen = Boolean(e.data.__sidesearch_panel);
    }
  });

  // ── 2. Track the last real focused element ────────────────────────────────
  const origAEL = EventTarget.prototype.addEventListener;
  origAEL.call(document, "focusin", (e) => {
    if (!panelOpen) lastActiveElement = e.target;
  }, true);

  // ── 3. document.hidden ────────────────────────────────────────────────────
  const hiddenDesc = Object.getOwnPropertyDescriptor(Document.prototype, "hidden");
  Object.defineProperty(Document.prototype, "hidden", {
    get() { return panelOpen ? false : hiddenDesc.get.call(this); },
    configurable: true,
  });

  // ── 4. document.visibilityState ───────────────────────────────────────────
  const visDesc = Object.getOwnPropertyDescriptor(Document.prototype, "visibilityState");
  Object.defineProperty(Document.prototype, "visibilityState", {
    get() { return panelOpen ? "visible" : visDesc.get.call(this); },
    configurable: true,
  });

  // ── 5. document.hasFocus() ────────────────────────────────────────────────
  const origHasFocus = Document.prototype.hasFocus;
  Document.prototype.hasFocus = function () {
    return panelOpen ? true : origHasFocus.call(this);
  };

  // ── 6. document.activeElement ─────────────────────────────────────────────
  const origActiveDesc = Object.getOwnPropertyDescriptor(Document.prototype, "activeElement");
  if (origActiveDesc && origActiveDesc.get) {
    Object.defineProperty(Document.prototype, "activeElement", {
      get() {
        if (panelOpen && lastActiveElement && document.contains(lastActiveElement)) {
          return lastActiveElement;
        }
        return origActiveDesc.get.call(this);
      },
      configurable: true,
    });
  }

  // ── 7. Wrap addEventListener — suppress detection events everywhere ────────
  //    Covers window, document, AND any element (e.g. quiz input boxes).
  const SUPPRESSED = new Set(["blur", "focusout", "visibilitychange", "pagehide"]);

  EventTarget.prototype.addEventListener = function (type, listener, options) {
    if (!SUPPRESSED.has(type)) {
      return origAEL.call(this, type, listener, options);
    }
    const wrapped = function (event) {
      if (panelOpen) {
        event.stopImmediatePropagation();
        return;
      }
      if (typeof listener === "function") {
        return listener.call(this, event);
      }
      return listener.handleEvent.call(listener, event);
    };
    wrapped.__sidesearch_orig = listener;
    return origAEL.call(this, type, wrapped, options);
  };

  // ── 8. removeEventListener — unwrap correctly ────────────────────────────
  const origREL = EventTarget.prototype.removeEventListener;
  EventTarget.prototype.removeEventListener = function (type, listener, options) {
    if (SUPPRESSED.has(type)) {
      // Find the wrapped version we stored
      const listeners = this.__sidesearch_listeners?.[type];
      if (listeners) {
        const idx = listeners.findIndex((w) => w.__sidesearch_orig === listener);
        if (idx !== -1) {
          const [wrapped] = listeners.splice(idx, 1);
          return origREL.call(this, type, wrapped, options);
        }
      }
    }
    return origREL.call(this, type, listener, options);
  };

  // ── 9. Intercept inline on* properties ───────────────────────────────────
  function makeGatedProp(host, prop, fireWhenOpen = false) {
    let stored = null;
    Object.defineProperty(host, prop, {
      get() { return stored; },
      set(fn) {
        stored = fn
          ? function (e) { if (fireWhenOpen ? panelOpen : !panelOpen) fn.call(this, e); }
          : fn;
      },
      configurable: true,
    });
  }

  // window
  makeGatedProp(window, "onblur");
  makeGatedProp(window, "onfocusout");
  makeGatedProp(window, "onvisibilitychange");
  makeGatedProp(window, "onpagehide");
  makeGatedProp(window, "onfocus");   // gate focus too — fires on "return from away"

  // document
  makeGatedProp(document, "onblur");
  makeGatedProp(document, "onfocusout");
  makeGatedProp(document, "onvisibilitychange");

  // ── 10. Raw capture listeners — last line of defence ─────────────────────
  //    These run FIRST (capture phase) using the original AEL, so they fire
  //    before any handler registered by Canvas (since we set up before Canvas).
  const swallow = (e) => {
    if (panelOpen) e.stopImmediatePropagation();
  };

  origAEL.call(window,   "blur",             swallow, { capture: true });
  origAEL.call(window,   "focusout",         swallow, { capture: true });
  origAEL.call(window,   "visibilitychange", swallow, { capture: true });
  origAEL.call(window,   "pagehide",         swallow, { capture: true });
  origAEL.call(document, "blur",             swallow, { capture: true });
  origAEL.call(document, "focusout",         swallow, { capture: true });
  origAEL.call(document, "visibilitychange", swallow, { capture: true });

})();
