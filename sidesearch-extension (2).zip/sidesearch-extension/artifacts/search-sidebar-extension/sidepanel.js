// ── Notify background that the panel is open ──────
// This triggers focus-suppression in the active tab's page context.
chrome.runtime.sendMessage({ type: "PANEL_OPENED" }).catch(() => {});
window.addEventListener("pagehide", () => {
  chrome.runtime.sendMessage({ type: "PANEL_CLOSED" }).catch(() => {});
});

// ── State ─────────────────────────────────────────
let currentQuery = "";
let frameLoadTimer = null;

// ── Element refs ──────────────────────────────────
const homeScreen           = document.getElementById("home-screen");
const resultsScreen        = document.getElementById("results-screen");
const searchForm           = document.getElementById("search-form");
const searchInput          = document.getElementById("search-input");
const clearBtn             = document.getElementById("clear-btn");
const suggestionsContainer = document.getElementById("suggestions-container");
const suggestionsList      = document.getElementById("suggestions-list");
const resultsSearchForm    = document.getElementById("results-search-form");
const resultsSearchInput   = document.getElementById("results-search-input");
const resultsFrame         = document.getElementById("results-frame");
const backBtn              = document.getElementById("back-btn");
const openTabBtn           = document.getElementById("open-tab-btn");
const openTabBtn2          = document.getElementById("open-tab-btn-2");
const blockedNotice        = document.getElementById("blocked-notice");

// ── Helpers ───────────────────────────────────────
function googleUrl(q) {
  return `https://www.google.com/search?q=${encodeURIComponent(q)}&igu=1`;
}

function showScreen(name) {
  homeScreen.classList.toggle("active", name === "home");
  resultsScreen.classList.toggle("active", name === "results");
}

function doSearch(q) {
  q = q.trim();
  if (!q) return;
  currentQuery = q;

  // Update toolbar input
  resultsSearchInput.value = q;

  // Show results screen
  showScreen("results");
  blockedNotice.hidden = true;
  resultsFrame.style.display = "";

  // Load Google search inside the frame
  resultsFrame.src = googleUrl(q);

  // Detect if Google blocked the iframe (X-Frame-Options)
  clearTimeout(frameLoadTimer);
  frameLoadTimer = setTimeout(() => {
    try {
      const doc = resultsFrame.contentDocument || resultsFrame.contentWindow?.document;
      if (doc && (doc.URL === "about:blank" || doc.body?.innerHTML === "")) {
        showBlocked();
      }
    } catch {
      // Cross-origin exception = Google returned real HTML — all good
    }
  }, 4000);

  resultsFrame.addEventListener("load", () => {
    clearTimeout(frameLoadTimer);
    try {
      const doc = resultsFrame.contentDocument || resultsFrame.contentWindow?.document;
      if (doc && doc.URL !== googleUrl(q)) {
        if (doc.body?.innerHTML === "" || doc.URL === "about:blank") {
          showBlocked();
        }
      }
    } catch {
      // Cross-origin exception = Google loaded correctly
    }
  }, { once: true });
}

function showBlocked() {
  resultsFrame.style.display = "none";
  blockedNotice.hidden = false;
}

function openInNewTab() {
  chrome.tabs.create({ url: googleUrl(currentQuery) });
}

// ── Home search form ──────────────────────────────
searchInput.addEventListener("input", () => {
  const val = searchInput.value;
  clearBtn.hidden = val.length === 0;
  suggestionsContainer.hidden = true;
});

clearBtn.addEventListener("click", () => {
  searchInput.value = "";
  clearBtn.hidden = true;
  suggestionsContainer.hidden = true;
});

searchForm.addEventListener("submit", (e) => {
  e.preventDefault();
  doSearch(searchInput.value);
});

// ── Quick-link chips ──────────────────────────────
document.querySelectorAll(".chip").forEach((chip) => {
  chip.addEventListener("click", () => {
    searchInput.value = chip.dataset.query;
    doSearch(chip.dataset.query);
  });
});

// ── Results toolbar ───────────────────────────────
backBtn.addEventListener("click", () => {
  showScreen("home");
  searchInput.value = currentQuery;
  clearBtn.hidden = currentQuery.length === 0;
});

resultsSearchForm.addEventListener("submit", (e) => {
  e.preventDefault();
  doSearch(resultsSearchInput.value);
});

openTabBtn.addEventListener("click", openInNewTab);
openTabBtn2.addEventListener("click", openInNewTab);

// ── Keyboard shortcut: Enter in results bar ───────
resultsSearchInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    doSearch(resultsSearchInput.value);
  }
});

// ── Pre-fill from selected text on active tab ─────
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  if (!tabs[0]) return;
  chrome.scripting?.executeScript({
    target: { tabId: tabs[0].id },
    func: () => window.getSelection()?.toString().trim() || "",
  }).then((results) => {
    const selected = results?.[0]?.result;
    if (selected) {
      searchInput.value = selected;
      clearBtn.hidden = false;
      doSearch(selected);
    }
  }).catch(() => {});
});
