const fileInput = document.getElementById("file-input");
const chooseButton = document.getElementById("choose-button");
const clearButton = document.getElementById("clear-button");
const dropZone = document.getElementById("drop-zone");
const emptyState = document.getElementById("empty-state");
const viewer = document.getElementById("viewer");
const pdfFrame = document.getElementById("pdf-frame");
const fileName = document.getElementById("file-name");
const fileSize = document.getElementById("file-size");
const statusMessage = document.getElementById("status-message");

let currentObjectUrl = null;

chooseButton.addEventListener("click", () => fileInput.click());
clearButton.addEventListener("click", closeDocument);

fileInput.addEventListener("change", () => {
  const [file] = fileInput.files ?? [];
  if (file) void openPdf(file);
  fileInput.value = "";
});

for (const eventName of ["dragenter", "dragover"]) {
  dropZone.addEventListener(eventName, (event) => {
    event.preventDefault();
    dropZone.classList.add("is-dragging");
  });
}

for (const eventName of ["dragleave", "drop"]) {
  dropZone.addEventListener(eventName, (event) => {
    event.preventDefault();
    dropZone.classList.remove("is-dragging");
  });
}

dropZone.addEventListener("drop", (event) => {
  const file = event.dataTransfer?.files?.[0];
  if (file) void openPdf(file);
});

window.addEventListener("pagehide", releaseObjectUrl);

async function openPdf(file) {
  statusMessage.textContent = "";

  if (!file.name.toLowerCase().endsWith(".pdf") && file.type !== "application/pdf") {
    statusMessage.textContent = "Please choose a PDF file.";
    return;
  }

  try {
    const signature = new Uint8Array(await file.slice(0, 5).arrayBuffer());
    const signatureText = new TextDecoder().decode(signature);
    if (signatureText !== "%PDF-") {
      statusMessage.textContent = "This file doesn’t appear to be a valid PDF.";
      return;
    }
  } catch {
    statusMessage.textContent = "Couldn’t read that file. Please try choosing it again.";
    return;
  }

  releaseObjectUrl();
  currentObjectUrl = URL.createObjectURL(file);
  pdfFrame.src = currentObjectUrl;
  fileName.textContent = file.name;
  fileName.title = file.name;
  fileSize.textContent = formatFileSize(file.size);
  emptyState.hidden = true;
  viewer.hidden = false;
  clearButton.hidden = false;
}

function closeDocument() {
  pdfFrame.src = "about:blank";
  viewer.hidden = true;
  emptyState.hidden = false;
  clearButton.hidden = true;
  fileName.textContent = "No document open";
  fileName.removeAttribute("title");
  fileSize.textContent = "Choose a file to start reading";
  statusMessage.textContent = "";

  const urlToRelease = currentObjectUrl;
  currentObjectUrl = null;
  if (urlToRelease) window.setTimeout(() => URL.revokeObjectURL(urlToRelease), 250);
}

function releaseObjectUrl() {
  if (currentObjectUrl) {
    URL.revokeObjectURL(currentObjectUrl);
    currentObjectUrl = null;
  }
}

function formatFileSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}