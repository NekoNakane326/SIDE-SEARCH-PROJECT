# PDF Side Panel

A Chrome extension that opens a PDF selected from your device in Chrome's built-in PDF viewer inside the side panel. The file is not uploaded or saved by the extension.

## Install in Chrome

1. Download and unzip `pdf-side-panel.zip`.
2. Open `chrome://extensions` in Chrome.
3. Turn on **Developer mode**.
4. Select **Load unpacked** and choose the unzipped `pdf-side-panel` folder.
5. Pin **PDF Side Panel** from Chrome's Extensions menu.
6. Select the extension icon to open the panel, then choose a PDF or drop one into the panel.

The panel uses Chrome's built-in PDF renderer, so the extension itself does not need network access or a PDF service.

## Privacy and permissions

- The only permission is `sidePanel`, used to open the reader from the extension button.
- The extension reads a PDF only after you choose or drop it.
- It creates a temporary local object URL for the built-in PDF viewer and releases it when you close the document or the panel.
- No websites, page content, browsing history, or Canvas data are read.